<?php

require_once( 'class-itsec-system-tweaks.php' );

ITSEC_System_Tweaks::activate();
