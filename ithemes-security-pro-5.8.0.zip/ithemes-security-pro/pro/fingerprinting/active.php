<?php
require_once( dirname( __FILE__ ) . '/class-itsec-fingerprinting.php' );
$fingerprinting = new ITSEC_Fingerprinting();
$fingerprinting->run();