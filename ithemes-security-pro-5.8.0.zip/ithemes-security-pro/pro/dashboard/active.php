<?php

require_once( dirname( __FILE__ ) . '/class-itsec-dashboard.php' );
$dashboard = new ITSEC_Dashboard();
$dashboard->run();